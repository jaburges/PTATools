# Auction Module

Sell items as WooCommerce **Auction** products with timed bidding, optional Buy It Now, max bid (auto-bid), and winner checkout. Payments run through WooCommerce checkout (e.g. Stripe via WooCommerce Stripe Gateway).

---

## 📋 Overview

| Feature | Description |
|---------|-------------|
| **Custom Product Type** | "Auction" product type in WooCommerce |
| **Bidding End** | Date and time when bidding closes |
| **Quick Bid Buttons** | +$5, +$10, +$20 on the product page |
| **Max Bid** | Set a maximum; system auto-bids when outbid (e.g. $5 increments) |
| **Masked Bidders** | Bidders shown as first 2 letters + "***" (e.g. Ja***) |
| **Buy It Now** | Optional fixed price to end the auction immediately |
| **Require Immediate Payment** | Buy It Now can send customer straight to checkout |
| **Audit Trail** | All bids and times stored in the database |
| **Winner Flow** | Order created for winner; "You won" email with checkout link |

---

## 📦 Requirements

- **WooCommerce** installed and activated
- **WooCommerce Stripe Gateway** (or other gateway) for Stripe payments—no separate Stripe SDK in the plugin
- Users must be **logged in** to bid

---

## ⚙️ Configuration

### Location
**Azure Plugin → Auction**

### Enable the Module

1. Go to **Azure Plugin** (PTA Tools) dashboard
2. Find the **Auction** module card
3. Toggle to enable
4. Click **Save Settings**
5. Click **Configure** for the Auction dashboard (stats, link to products)

### Creating an Auction Product

1. Go to **Products → Add New**
2. Set **Product type** to **Auction**
3. Open the **Auction** tab:
   - **Bidding End Date** / **Bidding End Time** – when bidding closes
   - **Buy It Now** – enable and set price (optional)
   - **Require immediate payment** – when checked, Buy It Now sends customer to checkout immediately
4. Set **Regular price** as the **starting (minimum) bid**
5. Publish the product

### How Bidding Works

- **Single product page**: Shows current price, bid input, quick buttons (+$5, +$10, +$20), and optional "Set max bid"
- **Recent bids**: Masked bidders (e.g. Ja***) and amounts
- **Login required**: Non-logged-in users see "Register/Login to bid"
- **Max bid**: If set, the system auto-bids up to that amount in increments when the user is outbid

### When the Auction Ends

- When the bidding end time has passed, the auction is marked ended (checked on product load)
- The winner is the user with the highest bid at end time
- A WooCommerce order is created for the winning amount
- The winner receives a "You won" email with a link to checkout to pay (Stripe or other gateways as configured)

### Buy It Now

- If enabled and the auction has not ended, a **Buy It Now** button appears
- On click, an order is created at the Buy It Now price and the customer is redirected to checkout
- The auction is marked sold so the normal "winner" flow does not run

---

## 📌 Notes

- Auction products are sold and bid on via the standard WooCommerce single product page; no shortcodes
- "You won" emails use `wp_mail` (or your plugin email module if you route transactional mail through it)
- For Stripe, use **WooCommerce Stripe Gateway**; the plugin does not call the Stripe API directly
