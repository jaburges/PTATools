# Quick Start Guide

Get Microsoft PTA up and running in 15 minutes! This guide covers the essentials to get your first module working.

---

## ⏱️ What We'll Do

**Option A: Setup Wizard (Recommended)**
1. Install the plugin (2 min)
2. Follow the guided Setup Wizard (10 min)
3. You're done!

**Option B: Manual Setup**
1. Install the plugin (2 min)
2. Create Azure App Registration (5 min)
3. Configure plugin credentials (2 min)
4. Enable your first module (3 min)
5. Test it works (3 min)

**Total time: ~15 minutes**

---

## Step 1: Install the Plugin

### Option A: Upload ZIP (Recommended)

1. Download the latest release from [GitHub](https://github.com/jaburges/AzureSSO/releases)
2. In WordPress, go to **Plugins → Add New → Upload Plugin**
3. Choose the ZIP file and click **Install Now**
4. Click **Activate**

### Option B: Manual Upload

1. Extract the ZIP file
2. Upload the `azure-plugin` folder to `/wp-content/plugins/`
3. Go to **Plugins** in WordPress admin
4. Find "Microsoft PTA" and click **Activate**

✅ **Success:** You should see "Azure Plugin" in your admin menu.

---

## Step 2: Setup Wizard (Recommended)

After activation, the Setup Wizard will appear automatically for new installations.

### 2.1 Welcome & Organization Info

1. **Welcome page** - Overview of what the wizard will help you configure
2. **Organization Info** - Enter your:
   - **Domain** (e.g., `yourptsa.net`)
   - **Organization Name** (e.g., `LWSD PTA`)
   - **Team Name** (e.g., `LWSD PTA Team`)
   - **Admin Email** (e.g., `admin@yourptsa.net`)

### 2.2 Module Selection

Choose which modules to enable:
- ☑️ SSO Authentication
- ☑️ Cloud Backup
- ☑️ Calendar Integration
- ☑️ Newsletter
- ☑️ PTA Roles
- ☑️ OneDrive Media

> 💡 You can always enable/disable modules later from the main dashboard.

### 2.3 Azure App Registration

1. Watch the placeholder video (or follow the [detailed guide](Azure-App-Registration))
2. Enter your credentials:
   - **Client ID**
   - **Client Secret**
   - **Tenant ID**
3. Click **Validate Connection** to test

### 2.4 Module-Specific Setup

The wizard guides you through each enabled module:

- **Backup**: Enter Azure Storage credentials
- **PTA Roles**: Import default tables, pull from Azure AD
- **SSO**: Configure login button and default role
- **OneDrive**: Authorize access and select folder

### 2.5 Summary

Review your settings and click **Complete Setup**.

✅ **Success:** Your plugin is configured and ready to use!

---

## Alternative: Manual Setup

If you prefer to skip the wizard, here's the manual process:

### Create Azure App Registration

1. Go to [portal.azure.com](https://portal.azure.com)
2. Sign in with your Microsoft 365 admin account
3. Search for "App registrations"
4. Click **+ New registration**

| Field | Value |
|-------|-------|
| **Name** | `WordPress Integration` |
| **Supported account types** | Accounts in this organizational directory only |
| **Redirect URI - Platform** | Web |
| **Redirect URI - URL** | `https://yoursite.com/wp-admin/admin-ajax.php?action=azure_sso_callback` |

> ⚠️ Replace `yoursite.com` with your actual domain!

5. Click **Register**

### Note Your Credentials

On the Overview page, copy:
- **Application (client) ID** → This is your Client ID
- **Directory (tenant) ID** → This is your Tenant ID

### Create Client Secret

1. Click **Certificates & secrets**
2. Click **+ New client secret**
3. Description: `WordPress Plugin`, Expires: `24 months`
4. Click **Add**
5. **IMMEDIATELY copy the Value** (shown only once!)

### Add API Permissions

1. Click **API permissions**
2. Click **+ Add a permission** → **Microsoft Graph**
3. Add permissions based on modules you'll use:

| Module | Permission | Type |
|--------|------------|------|
| SSO | `User.Read` | Delegated |
| Calendar | `Calendars.Read` | Delegated |
| Email | `Mail.Send` | Delegated |
| PTA Roles | `Group.Read.All` | Application |
| Newsletter | `Mail.Send` | Application |

4. Click **Grant admin consent**

### Configure Plugin

1. Go to **Azure Plugin** in WordPress admin
2. Enter your Client ID, Client Secret, and Tenant ID
3. Click **Test Connection** to verify
4. Enable desired modules

---

## 🎉 What's Next?

Now that you have the basics working, explore more modules:

### Popular Next Steps

| Module | What It Does | Guide |
|--------|--------------|-------|
| **Newsletter** | Visual email editor with analytics | [Newsletter Guide](Newsletter-Module) |
| **Calendar Embed** | Display Outlook calendars | [Calendar Embed Guide](Calendar-Embed-Module) |
| **Backup** | Automatic backups to Azure | [Backup Guide](Backup-Module) |
| **PTA Roles** | Manage volunteers | [PTA Roles Guide](PTA-Roles-Module) |

### Module Comparison

| Need | Recommended Module |
|------|-------------------|
| Send email newsletters | Newsletter |
| Show Outlook calendar on site | Calendar Embed |
| Sync events to The Events Calendar | Calendar Sync |
| Send reliable transactional emails | Email |
| Back up to cloud | Backup |
| Manage volunteer roles | PTA Roles |
| Sell classes with events | Classes |

---

## 🆘 Quick Troubleshooting

### "Invalid redirect URI"
- Check that the redirect URI in Azure exactly matches your site URL
- Ensure you're using HTTPS
- The full URI should be: `https://yoursite.com/wp-admin/admin-ajax.php?action=azure_sso_callback`

### "Consent required"
- Go back to Azure → API permissions
- Click "Grant admin consent"
- Make sure all permissions have green checkmarks

### "Connection failed"
- Verify Client ID, Secret, and Tenant ID are correct
- Check that the client secret hasn't expired
- Ensure no extra spaces in the credential fields

### Re-run Setup Wizard
- Go to **Azure Plugin → System Logs**
- Scroll to **Danger Zone**
- Click **Reset Setup Wizard**
- Navigate to Setup Wizard from the main menu

### Need More Help?
- Check [Troubleshooting](Troubleshooting) for more solutions
- Review the [Installation](Installation) guide for detailed steps
- [Open an issue](https://github.com/jaburges/AzureSSO/issues) on GitHub

---

*Congratulations on getting started! 🎉 Explore the [module guides](Home) to unlock more features.*
